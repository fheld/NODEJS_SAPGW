/*!
 * jQuery MobiScroll v2.5.0
 * http://mobiscroll.com
 *
 * Copyright 2010-2013, Acid Media
 * Licensed under the MIT license.
 *
 */
(function($){$.mobiscroll.themes.ios={defaults:{dateOrder:'MMdyy',rows:5,height:30,width:55,headerText:false,showLabel:false}}})(jQuery);
