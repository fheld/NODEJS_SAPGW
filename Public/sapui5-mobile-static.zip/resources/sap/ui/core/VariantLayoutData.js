/*!
 * SAP UI development toolkit for HTML5 (SAPUI5)
 * 
 * (c) Copyright 2009-2013 SAP AG. All rights reserved
 */
jQuery.sap.declare("sap.ui.core.VariantLayoutData");jQuery.sap.require("sap.ui.core.library");jQuery.sap.require("sap.ui.core.LayoutData");sap.ui.core.LayoutData.extend("sap.ui.core.VariantLayoutData",{metadata:{library:"sap.ui.core",aggregations:{"multipleLayoutData":{type:"sap.ui.core.LayoutData",multiple:true,singularName:"multipleLayoutData"}}}});
