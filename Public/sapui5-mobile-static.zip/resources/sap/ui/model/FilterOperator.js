/*!
 * SAP UI development toolkit for HTML5 (SAPUI5)
 * 
 * (c) Copyright 2009-2013 SAP AG. All rights reserved
 */
jQuery.sap.declare("sap.ui.model.FilterOperator");sap.ui.model.FilterOperator={EQ:"EQ",NE:"NE",LT:"LT",LE:"LE",GT:"GT",GE:"GE",BT:"BT",Contains:"Contains",StartsWith:"StartsWith",EndsWith:"EndsWith"};
