/*!
 * SAP UI development toolkit for HTML5 (SAPUI5)
 * 
 * (c) Copyright 2009-2013 SAP AG. All rights reserved
 */
jQuery.sap.declare("sap.m.DisplayListItem");jQuery.sap.require("sap.m.library");jQuery.sap.require("sap.m.ListItemBase");sap.m.ListItemBase.extend("sap.m.DisplayListItem",{metadata:{library:"sap.m",properties:{"label":{type:"string",group:"Misc",defaultValue:null},"value":{type:"string",group:"Data",defaultValue:null}}}});
