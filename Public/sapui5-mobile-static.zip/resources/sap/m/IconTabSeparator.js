/*!
 * SAP UI development toolkit for HTML5 (SAPUI5)
 * 
 * (c) Copyright 2009-2013 SAP AG. All rights reserved
 */
jQuery.sap.declare("sap.m.IconTabSeparator");jQuery.sap.require("sap.m.library");jQuery.sap.require("sap.ui.core.Element");sap.ui.core.Element.extend("sap.m.IconTabSeparator",{metadata:{interfaces:["sap.m.IconTab"],library:"sap.m",properties:{"icon":{type:"sap.ui.core.URI",group:"Misc",defaultValue:''}}}});
