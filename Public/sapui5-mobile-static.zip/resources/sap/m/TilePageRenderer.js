/*!
 * SAP UI development toolkit for HTML5 (SAPUI5)
 * 
 * (c) Copyright 2009-2013 SAP AG. All rights reserved
 */
jQuery.sap.declare("sap.m.TilePageRenderer");sap.m.TilePageRenderer={};sap.m.TilePageRenderer=sap.ui.core.Renderer.extend(sap.m.PageRenderer);
